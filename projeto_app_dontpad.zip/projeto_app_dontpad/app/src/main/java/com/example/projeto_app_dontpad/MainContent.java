package com.example.projeto_app_dontpad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.content.Intent;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.GridView;
import android.widget.Toast;

public class MainContent extends AppCompatActivity {

    Button textButton;
    ImageView camButton;
    GridView galleryImageView;
    private static final int REQUEST_IMAGE_CAPTURE = 1;

    int photos[] = {R.drawable.palio,R.drawable.palio2,R.drawable.palio3,
            R.drawable.palio4,R.drawable.palio5,R.drawable.palio6,
            R.drawable.palio7,R.drawable.palio8,R.drawable.palio9};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.images);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.content_main);

        galleryImageView = findViewById(R.id.galleryGridView);
        ViewCompat.setNestedScrollingEnabled(galleryImageView,true);
        Adapter adapter = new Adapter(getApplicationContext(),photos);
        galleryImageView.setAdapter(adapter);
        galleryImageView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent fullImage = new Intent(getApplicationContext(),MainContentFull.class);
                fullImage.putExtra("displayImageView", photos[position]);
                startActivity(fullImage);
            }
        });

        //botão camera
        camButton = findViewById(R.id.camButton);
        camButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (camera.resolveActivity(getPackageManager())!=null) {
                    startActivityForResult(camera, REQUEST_IMAGE_CAPTURE);
                }
            }
        });


        //botão texto

        textButton = findViewById(R.id.textButton);
        textButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent imageScreen = new Intent(getBaseContext(),MainActivity.class);
                startActivity(imageScreen);
            }
        });


    }

}