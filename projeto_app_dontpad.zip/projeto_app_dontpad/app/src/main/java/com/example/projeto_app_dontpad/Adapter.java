package com.example.projeto_app_dontpad;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ScrollView;

public class Adapter extends BaseAdapter {

    Context context;
    int photos[];
    LayoutInflater inflater;

    public Adapter(Context applicationContext, int[] photos){
        this.context=applicationContext;
        this.photos=photos;
        inflater=(LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return photos.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i){
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view = inflater.inflate(R.layout.display_main,null);
        final ImageView photo=view.findViewById(R.id.displayImageView);
        photo.setImageResource(photos[i]);
        return view;
    }
}
