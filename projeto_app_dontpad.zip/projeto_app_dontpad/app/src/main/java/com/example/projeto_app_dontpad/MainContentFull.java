package com.example.projeto_app_dontpad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainContentFull extends AppCompatActivity {

    private Button textButton;
    private Button photoButton;
    private ImageView backButton;
    private ImageView fullImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.images);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.content_main_full);
        fullImage = findViewById(R.id.galleryImageView);
        int photo = getIntent().getIntExtra("displayImageView", R.drawable.ic_launcher_background);
        fullImage.setImageResource(photo);

        //botão voltar
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imageScreen = new Intent(getBaseContext(),MainContent.class);
                startActivity(imageScreen);
            }
        });

        //botão texto
        textButton = findViewById(R.id.textButton);
        textButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imageScreen = new Intent(getBaseContext(), MainActivity.class);
                startActivity(imageScreen);
            }
        });

        //botão fotos
        photoButton = findViewById(R.id.photoButton);
        photoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imageScreen = new Intent(getBaseContext(), MainContent.class);
                startActivity(imageScreen);
            }
        });
    }
}
